#include "Library.h"
#include <iostream>
using namespace std;

void Library::addBook(Book book) {
    books.push_back(book);
}

bool Library::removeBook(string isbn) {
    for (vector<Book>::iterator it = books.begin(); it != books.end(); ++it) {
        if (it->getISBN() == isbn && !it->getIsBorrowed()) {
            books.erase(it);
            return true;
        }
    }
    return false;
}

void Library::addUser(User user) {
    users.push_back(user);
}

User* Library::getUserById(string userId) {
    for (size_t i = 0; i < users.size(); i++) {
        if (users[i].getId() == userId) return &users[i];
    }
    return NULL;
}

Book* Library::getBookByISBN(string isbn) {
    for (size_t i = 0; i < books.size(); i++) {
        if (books[i].getISBN() == isbn) return &books[i];
    }
    return NULL;
}

bool Library::borrowBook(string userId, string isbn) {
    Book* book = getBookByISBN(isbn);
    User* user = getUserById(userId);

    if (book != NULL && user != NULL && !book->getIsBorrowed()) {
        if (book->borrow()) {
            user->borrowBook(isbn);
            return true;
        }
    }
    return false;
}

bool Library::returnBook(string userId, string isbn) {
    Book* book = getBookByISBN(isbn);
    User* user = getUserById(userId);

    if (book != NULL && user != NULL && book->getIsBorrowed()) {
        if (book->giveBack()) {
            return user->returnBook(isbn);
        }
    }
    return false;
}

void Library::searchBooks(string keyword) const {
    for (size_t i = 0; i < books.size(); i++) {
        if (books[i].getTitle().find(keyword) != string::npos ||
            books[i].getAuthor().find(keyword) != string::npos ||
            books[i].getISBN().find(keyword) != string::npos) {
            cout << "Title: " << books[i].getTitle()
                 << ", Author: " << books[i].getAuthor()
                 << ", ISBN: " << books[i].getISBN()
                 << ", Borrowed: " << (books[i].getIsBorrowed() ? "Yes" : "No") << endl;
        }
    }
}
