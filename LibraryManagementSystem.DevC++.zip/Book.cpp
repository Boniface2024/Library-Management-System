#include "Book.h"
#include <iostream>
using namespace std;

Book::Book(string t, string a, string i)
    : title(t), author(a), isbn(i), isBorrowed(false) {}

string Book::getTitle() const { return title; }
string Book::getAuthor() const { return author; }
string Book::getISBN() const { return isbn; }
bool Book::getIsBorrowed() const { return isBorrowed; }

bool Book::borrow() {
    if (!isBorrowed) {
        isBorrowed = true;
        return true;
    }
    return false;
}

bool Book::giveBack() {
    if (isBorrowed) {
        isBorrowed = false;
        return true;
    }
    return false;
}
