#ifndef USER_H
#define USER_H

#include <string>
#include <vector>
using namespace std;

class User {
private:
    string name;
    string userId;
    vector<string> borrowedBooks;

public:
    User(string name, string id);

    string getName() const;
    string getId() const;
    vector<string> getBorrowedBooks() const;

    void borrowBook(string isbn);
    bool returnBook(string isbn);
};

#endif
