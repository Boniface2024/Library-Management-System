#ifndef LIBRARY_H
#define LIBRARY_H

#include "Book.h"
#include "User.h"
#include <vector>
using namespace std;

class Library {
private:
    vector<Book> books;
    vector<User> users;

public:
    void addBook(Book book);
    bool removeBook(string isbn);

    void addUser(User user);
    User* getUserById(string userId);
    Book* getBookByISBN(string isbn);

    bool borrowBook(string userId, string isbn);
    bool returnBook(string userId, string isbn);
    void searchBooks(string keyword) const;
};

#endif
