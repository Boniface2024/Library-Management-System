#include <iostream>
#include "Library.h"
using namespace std;

int main() {
    Library lib;

    lib.addBook(Book("C++ Basics", "Bjarne", "111"));
    lib.addBook(Book("Python 101", "Guido", "222"));
    lib.addUser(User("Boniface", "U1"));

    cout << "Search results for 'C++':" << endl;
    lib.searchBooks("C++");

    if (lib.borrowBook("U1", "111")) {
        cout << "Book borrowed successfully!" << endl;
    }

    if (lib.returnBook("U1", "111")) {
        cout << "Book returned successfully!" << endl;
    }

    return 0;
}
