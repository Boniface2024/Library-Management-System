#include "User.h"
#include <iostream>
using namespace std;

User::User(string n, string id) : name(n), userId(id) {}

string User::getName() const { return name; }
string User::getId() const { return userId; }

vector<string> User::getBorrowedBooks() const {
    return borrowedBooks;
}

void User::borrowBook(string isbn) {
    borrowedBooks.push_back(isbn);
}

bool User::returnBook(string isbn) {
    for (vector<string>::iterator it = borrowedBooks.begin(); it != borrowedBooks.end(); ++it) {
        if (*it == isbn) {
            borrowedBooks.erase(it);
            return true;
        }
    }
    return false;
}
